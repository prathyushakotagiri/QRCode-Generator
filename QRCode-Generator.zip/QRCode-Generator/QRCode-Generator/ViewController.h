//
//  ViewController.h
//  QRCode-Generator
//
//  Created by Prathyusha kotagiri on 11/17/15.
//  Copyright © 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    CIImage *qrCodeCIImage;
}

@property (strong, nonatomic) IBOutlet UITextField *textField;

@property (strong, nonatomic) IBOutlet UIButton *btnAction;

@property (strong, nonatomic) IBOutlet UIImageView *imgQRCode;

@property (strong, nonatomic) IBOutlet UISlider *slider;

- (IBAction)transformImage:(id)sender;

- (IBAction)generateQRCode:(id)sender;

@end

