//
//  ViewController.m
//  QRCode-Generator
//
//  Created by Prathyusha kotagiri on 11/17/15.
//  Copyright © 2015 Prathyusha kotagiri. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)generateQRCode:(id)sender {
    
    if (qrCodeCIImage == nil) {
        
        if ([_textField.text  isEqual: @""]){
            return ;
        }
        
        NSData *data = [self.textField.text dataUsingEncoding:NSISOLatin1StringEncoding allowLossyConversion:false];
        
        CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
        [filter setValue:data forKey:@"inputMessage"];
        [filter setValue:@"Q" forKey:@"inputCorrectionLevel"];
        
        qrCodeCIImage = filter.outputImage;
        
        [_textField resignFirstResponder];
        
        [self.btnAction setTitle:@"Clear" forState:UIControlStateNormal];
        
        [self displayQRCodeImage];
        
    }else{
        
        self.imgQRCode.image = nil;
        qrCodeCIImage = nil;
        [self.btnAction setTitle:@"Generate" forState:UIControlStateNormal];

    }
    
    self.textField.enabled = !self.textField.enabled;
    
    self.slider.hidden = !self.slider.hidden;

}

- (IBAction)transformImage:(id)sender {
    self.imgQRCode.transform = CGAffineTransformMakeScale(_slider.value , _slider.value);
}


-(void)displayQRCodeImage{
   
    float scaleX = self.imgQRCode.frame.size.width / qrCodeCIImage.extent.size.width;
    float scaleY = self.imgQRCode.frame.size.height / qrCodeCIImage.extent.size.height;
    
    CIImage *transformedImage = [qrCodeCIImage imageByApplyingTransform:CGAffineTransformMakeScale(scaleX, scaleY)];
    
    _imgQRCode.image = [UIImage imageWithCIImage:transformedImage];
}

//- (NSString *)vCardRepresentation
//{
//    NSMutableArray *mutableArray = [[NSMutableArray alloc] init];
//    
//    [mutableArray addObject:@"BEGIN:VCARD"];
//    [mutableArray addObject:@"VERSION:3.0"];
//    
//    [mutableArray addObject:[NSString stringWithFormat:@"FN:Santhosh kotagiri"]];
//    
//    [mutableArray addObject:[NSString stringWithFormat:@"ADR:;;505001,India"]];
//    
//    [mutableArray addObject:[NSString stringWithFormat:@"TEL:9849421365"]];
//    
////    [mutableArray addObject:[NSString stringWithFormat:@"GEO:%g;%g",
////                             self.latitudeValue, self.longitudeValue]];
////    
////    [mutableArray addObject:[NSString stringWithFormat:@"URL:http://%@",
////                             self.website]];
//    
//    [mutableArray addObject:@"END:VCARD"];
//    
//    NSString *string = [mutableArray componentsJoinedByString:@"\n"];
//    
//    return string;
//}

@end
