//
//  AppDelegate.h
//  QRCode-Generator
//
//  Created by Prathyusha kotagiri on 11/17/15.
//  Copyright © 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

